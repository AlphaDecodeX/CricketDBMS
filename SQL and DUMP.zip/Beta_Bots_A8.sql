use cricket_management_system;

-- Q1
CREATE TABLE person_hash_index AS SELECT * FROM person;
create index player_index using hash on person_hash_index(first_name(10));
set profiling =1; 
(SELECT * FROM person WHERE first_name like 'Y%'
UNION
SELECT * FROM person WHERE last_name like 'S%');
-- optimized query
(SELECT * FROM person_hash_index WHERE first_name like 'Y%'
UNION
SELECT * FROM person_hash_index WHERE last_name like 'S%');
show profiles;

explain (SELECT * FROM person_hash_index WHERE first_name like 'Y%'
UNION
SELECT * FROM person_hash_index WHERE last_name like 'S%');


-- Q2
set profiling =1; 
SELECT * FROM person WHERE first_name like 'R%';
-- optimized query
SELECT * FROM person_hash_index WHERE first_name like 'R%';
show profiles;
explain SELECT * FROM person_hash_index WHERE first_name like 'R%';


-- Q3
CREATE TABLE player_id_hash_index AS SELECT * FROM person;
create unique index player_id_index using hash on player_id_hash_index(id);
ALTER TABLE player_id_hash_index
modify id tinyint;
set profiling =1;
select * from person where id = 1;
-- optimized query
select * from player_id_hash_index where id =1;
show profiles;
explain select * from player_id_hash_index where id =1;


-- Q4
alter table match_info
add date_on_match_played date;

update match_info set date_on_match_played = '2003-05-20' where match_id =1001;
update match_info set date_on_match_played = '2008-01-17' where match_id =1002;
update match_info set date_on_match_played = '2011-10-04' where match_id =1003;
update match_info set date_on_match_played = '2013-06-26' where match_id =1004;
update match_info set date_on_match_played = '2014-11-30' where match_id =1005;

CREATE TABLE match_info_btree_index AS SELECT * FROM match_info;
create unique index date_index using btree on match_info_btree_index(date_on_match_played);
set profiling =1;
(select * from match_info where date_on_match_played > '2013-11-30' 
union 
select * from match_info where date_on_match_played < '2004-11-30');
-- optimized query
(select * from match_info_btree_index where date_on_match_played > '2013-11-30'
union
select * from match_info_btree_index where date_on_match_played < '2004-11-30');
show profiles;

explain (select * from match_info_btree_index where date_on_match_played > '2013-11-30'
union
select * from match_info_btree_index where date_on_match_played < '2004-11-30');


-- Q5
CREATE TABLE match_duplicate AS SELECT * FROM match_info;
select * from match_duplicate;
Update match_duplicate
Set india_total_runs = NULL where match_id = 1003 ;
Select Count(*) from match_duplicate where india_total_runs = true;

explain Select Count(*) from match_duplicate where india_total_runs = true;
-- Q6
-- Answer is written in docx
show variables like 'query_cache_size';


-- Q7
-- advantages and disadvantages are written in docx.
-- index already created in Q4
set profiling = 1;
select * from match_info natural join venue_info where date_on_match_played = '2008-01-17';
-- optimized query
select * from match_info_btree_index natural join venue_info where date_on_match_played = '2008-01-17';
show profiles;

explain select * from match_info_btree_index natural join venue_info where date_on_match_played = '2008-01-17';


-- Q8
CREATE TABLE person_id_hash_index AS SELECT * FROM person;
create unique index person_id_index using hash on person_id_hash_index(id);
CREATE TABLE player_match_info_hash_index AS SELECT * FROM player_match_info;
create index player_match_info_index using hash on player_match_info_hash_index(match_id);
CREATE TABLE stadium_name_hash_index AS SELECT * FROM venue_info;
create unique index stadium_name_index using hash on stadium_name_hash_index(stadium_name(20));
set profiling =1;
select * from person where id in  (select id from player_match_info where
match_id = (select match_id from venue_info where stadium_name = 'Wankhede Stadium' ));
-- optimized query
select * from person_id_hash_index where id in  (select id from player_match_info_hash_index where
match_id = (select match_id from stadium_name_hash_index where stadium_name = 'Wankhede Stadium' ));
show profiles;

explain select * from person_id_hash_index where id in  (select id from player_match_info_hash_index where
match_id = (select match_id from stadium_name_hash_index where stadium_name = 'Wankhede Stadium' ));